# !/usr/bin/python 
from crawler import Bot

# Create a instance for bot
bot = Bot()

# Get dog data
bot.get_dogs("diary")