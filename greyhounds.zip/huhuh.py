bends = list("3-6-")


print(list(bends))